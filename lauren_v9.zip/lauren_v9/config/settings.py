"""
LAUREN V9 - Configuration Settings
===================================
All tunable parameters in one place.
"""

# =============================================================================
# SIGNAL WEIGHTS (must sum to 1.0)
# =============================================================================

SIGNAL_WEIGHTS = {
    "quantum": 0.40,      # Mathematical mispricing (BS model, IV vs HV)
    "research": 0.35,     # News + fundamentals (Claude-analyzed)
    "flow": 0.15,         # Options flow (when available)
    "social": 0.10        # Social sentiment (when available)
}

# =============================================================================
# QUANTUM SCORE SETTINGS
# =============================================================================

# Score thresholds
SHORT_THRESHOLD = 0.40    # Score > 0.40 = SHORT signal
LONG_THRESHOLD = -0.30    # Score < -0.30 = LONG signal

# Score components
IV_HV_WEIGHT = 0.40       # Weight of IV vs HV divergence
PRICE_BS_WEIGHT = 0.60    # Weight of price vs Black-Scholes

# Historical volatility (annualized)
HISTORICAL_VOL = {
    "NVDL": 0.85,    # NVDA 2x
    "TSLL": 0.95,    # TSLA 2x
    "NVDA": 0.55,    # NVDA underlying
    "TSLA": 0.65     # TSLA underlying
}

# =============================================================================
# OPTION FILTERS
# =============================================================================

# Days to expiry
DTE_MIN = 5
DTE_MAX = 14

# OTM percentage (distance from current price)
MIN_OTM = 0.05    # At least 5% OTM
MAX_OTM = 0.20    # No more than 20% OTM

# Liquidity requirements
MIN_PREMIUM = 0.10      # At least $0.10
MIN_BID = 0.05          # At least $0.05 bid
MIN_OPEN_INTEREST = 10  # At least 10 OI
MAX_SPREAD_PCT = 0.15   # Max 15% bid-ask spread

# =============================================================================
# CONFIDENCE & TRADE DECISIONS
# =============================================================================

# Minimum confidence to trade
MIN_CONFIDENCE = 50

# Confidence adjustments
CONFIDENCE_BOOST_ALIGNED = 1.2      # Multiply when signals align
CONFIDENCE_PENALTY_CONFLICT = 0.7   # Multiply when 1 conflict
CONFIDENCE_PENALTY_MAJOR = 0.5      # Multiply when 2+ conflicts

# Catalyst adjustments
CATALYST_BOOST_STRONG = 1.2         # Multiply for catalyst_strength >= 8
CATALYST_PENALTY_WEAK = 0.9         # Multiply for catalyst_strength <= 3

# =============================================================================
# POSITION SIZING
# =============================================================================

# Maximum position as % of buying power
MAX_POSITION_PCT = 0.50     # 50% of buying power max per trade

# Maximum loss per trade
MAX_LOSS_DOLLARS = 500      # $500 max loss per trade

# Size adjustments based on confidence
SIZE_MULT = {
    "very_high": 1.0,       # Confidence >= 80
    "high": 0.7,            # Confidence >= 65
    "medium": 0.5,          # Confidence >= 50
    "low": 0.0              # Confidence < 50 = no trade
}

# Event-based size reductions
SIZE_MULT_EARNINGS_NEAR = 0.5    # Cut size when earnings within 3 days
SIZE_MULT_FOMC = 0.3             # Minimal size on FOMC days

# =============================================================================
# EXIT RULES
# =============================================================================

# Profit target
PROFIT_TARGET_PCT = 0.50    # Take profit at +50%

# Stop loss
STOP_LOSS_PCT = 0.40        # Stop at -40%

# Time-based exit
MIN_DTE_FOR_EXIT = 1        # Exit when DTE <= 1

# =============================================================================
# RESEARCH SETTINGS
# =============================================================================

# Maximum API calls per ticker per scan
MAX_SEARCHES_PER_TICKER = 6
MAX_PAGES_TO_READ = 3

# Research timeouts (seconds)
SEARCH_TIMEOUT = 10
READ_TIMEOUT = 15

# Daily API limits (for monitoring)
DAILY_SEARCH_LIMIT = 500
DAILY_CLAUDE_TOKEN_LIMIT = 100000

# =============================================================================
# SCAN SETTINGS
# =============================================================================

# Scan interval (seconds)
SCAN_INTERVAL = 180         # 3 minutes

# Market hours (Eastern)
MARKET_OPEN_HOUR = 9
MARKET_OPEN_MINUTE = 30
MARKET_CLOSE_HOUR = 16
MARKET_CLOSE_MINUTE = 0

# Tickers to scan
ACTIVE_TICKERS = ["NVDL", "TSLL"]

# Underlying mapping
UNDERLYING_MAP = {
    "NVDL": "NVDA",
    "TSLL": "TSLA",
    "NVDU": "NVDA",
    "TSLU": "TSLA"
}

# =============================================================================
# LOGGING
# =============================================================================

LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s | %(levelname)s | %(message)s"
LOG_FILE = "logs/lauren_v9.log"

# =============================================================================
# MACRO REGIME (updated daily)
# =============================================================================

MACRO_INDICATORS = {
    "SPY": None,    # Will be set at runtime
    "QQQ": None,
    "DIA": None
}

# Regime thresholds (% change for regime detection)
BULLISH_THRESHOLD = 0.005    # +0.5% = bullish
BEARISH_THRESHOLD = -0.005   # -0.5% = bearish
