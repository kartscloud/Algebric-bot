# LAUREN V9 - Autonomous Trading Agent

An AI-powered options trading agent that **thinks before it trades**.

## What Makes V9 Different

| Version | How It Decides |
|---------|----------------|
| V7/V8 | See mispricing → Trade |
| **V9** | See mispricing → Research → Think → Decide → Trade |

V9 is an **autonomous agent** that:
1. **SEES** - Scans option chains for mathematical mispricing
2. **THINKS** - "What do I need to know before trading this?"
3. **RESEARCHES** - Searches the web, reads articles, analyzes news
4. **REASONS** - Synthesizes everything into a decision
5. **ACTS** - Executes or passes based on its own judgment

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        LAUREN V9 - AUTONOMOUS TRADING AGENT                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                              ┌─────────────────┐                            │
│                              │   AGENT BRAIN   │                            │
│                              │    (Claude)     │                            │
│                              └────────┬────────┘                            │
│                                       │                                     │
│            ┌──────────────────────────┼──────────────────────────┐          │
│            │                          │                          │          │
│            ▼                          ▼                          ▼          │
│   ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐   │
│   │   PERCEPTION    │       │    RESEARCH     │       │    EXECUTION    │   │
│   │                 │       │                 │       │                 │   │
│   │ • Option chains │       │ • Web search    │       │ • Place orders  │   │
│   │ • Price data    │       │ • Read articles │       │ • Monitor P&L   │   │
│   │ • Greeks        │       │ • Parse filings │       │ • Manage exits  │   │
│   │ • Quantum score │       │ • Synthesize    │       │ • Risk limits   │   │
│   └─────────────────┘       └─────────────────┘       └─────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Signal Weights

| Signal | Weight | Source | Status |
|--------|--------|--------|--------|
| Quantum Score | 40% | Black-Scholes mispricing, IV vs HV | ✅ Ready |
| Research | 35% | News + catalysts (Claude-analyzed) | ✅ Ready |
| Flow | 15% | Options flow (Unusual Whales) | ❌ Need API key |
| Social | 10% | WSB/Congress/Insiders (Quiver Quant) | ✅ Ready |

## Installation

```bash
# Clone or copy to your machine
cd lauren_v9

# Install dependencies
pip install requests

# Edit credentials
nano config/credentials.py
```

## Configuration

Edit `config/credentials.py`:
```python
CLAUDE_API_KEY = "sk-ant-..."      # For research synthesis
SERPER_API_KEY = "..."             # For web search
NEWS_API_KEY = "..."               # Optional, for direct news
QUIVER_QUANT_KEY = "..."           # For WSB/Congress/Insiders
UNUSUAL_WHALES_KEY = None          # For options flow (need to add)
```

Edit `config/settings.py` for thresholds, weights, and risk limits.

## Usage

### Paper Trading (Test Mode)
```bash
python agents/trading_agent.py
```

### Single Scan (Debug)
```bash
python agents/trading_agent.py --single
```

### Live Trading (Careful!)
```bash
python agents/trading_agent.py --live --buying-power 5000
```

## File Structure

```
lauren_v9/
├── config/
│   ├── credentials.py    # API keys (gitignore this!)
│   └── settings.py       # All tunable parameters
│
├── agents/
│   ├── research_agent.py # Web search + Claude analysis
│   └── trading_agent.py  # Main agent loop
│
├── signals/
│   ├── fusion.py         # Combine all signals
│   └── social.py         # Quiver Quant (WSB/Congress/Insiders)
│
├── data/
│   └── state.json        # Positions, history
│
└── logs/
    └── lauren_v9.log     # Activity log
```

## How Research Works

When the agent finds a potential trade, it:

1. **Generates search queries** using Claude:
   - "TSLA news today"
   - "Tesla earnings date 2025"
   - "TSLA analyst upgrades"
   - etc.

2. **Searches the web** using Serper API

3. **Reads the best articles** using Jina Reader

4. **Synthesizes everything** with Claude:
   - What's the sentiment?
   - Any upcoming catalysts?
   - Does research support or conflict with the trade?
   - Risk factors?

5. **Returns a structured decision**:
   ```json
   {
     "sentiment_score": 0.65,
     "catalyst_detected": true,
     "catalyst_type": "earnings",
     "supports_direction": false,
     "recommendation": "SKIP",
     "reasoning": "Quantum says SHORT but earnings beat + upgrades = bullish"
   }
   ```

## Example Output

```
============================================================
SCAN CYCLE #1
============================================================
Scanning NVDL (NVDA)...
Scanning TSLL (TSLA)...
  ✓ Candidate: TSLL 20.0 CALL | Score: 0.68 | Dir: SHORT

📊 Evaluating TSLL 20.0 CALL...

============================================================
🔍 RESEARCHING: TSLL 20.0 CALL (SHORT)
============================================================
📋 Generated 6 search queries
   ✓ 'TSLA news today' → 5 results
   ✓ 'Tesla earnings date 2025' → 5 results
📖 Reading 3 articles...
   ✓ Read: https://reuters.com/...
🧠 Synthesizing research...

📊 RESEARCH RESULT for TSLL SHORT:
   Recommendation: SKIP
   Confidence adjustment: -20
   Reasoning: Tesla beat deliveries, analyst upgrades. Bullish sentiment conflicts with SHORT signal.

❌ REJECTED: Quantum: SHORT (72% conf) | Research: BULLISH | ⚠️ 1 conflict(s) detected
```

## API Costs

Per scan (2 tickers):
- Serper: ~12 searches = $0.006
- Claude: ~10k tokens = $0.03
- **Total: ~$0.04 per scan**

Daily (130 scans): **~$5/day**

## Status

- [x] Quantum score signal (BS mispricing)
- [x] Research agent (web search + Claude synthesis)
- [x] Social signal (Quiver Quant - WSB/Congress/Insiders)
- [x] Signal fusion with conflict detection
- [ ] Options flow integration (need Unusual Whales API key)
- [ ] Robinhood live trading integration
- [ ] Discord/SMS alerts

## Security

⚠️ **Never commit credentials.py to git!**

Add to `.gitignore`:
```
config/credentials.py
data/
logs/
```
