"""
LAUREN V9 - Social Sentiment Signal
=====================================
Tracks retail sentiment, congress trades, insider activity, and dark pool flow
using Quiver Quant API.

Weight: 15% of final signal
"""

import requests
from datetime import datetime, timedelta
from typing import Optional
from dataclasses import dataclass


@dataclass
class SocialSignal:
    """Social sentiment analysis result."""
    
    # Overall
    score: float              # -1.0 to +1.0
    direction: str            # "BULLISH" | "BEARISH" | "NEUTRAL"
    confidence: int           # 0-100
    
    # WSB Data
    wsb_mentions_24h: int
    wsb_mentions_7d: int
    wsb_rank: Optional[int]   # Rank among all tickers (lower = more popular)
    wsb_sentiment: float      # -1.0 to +1.0
    is_memeing: bool          # Unusual retail attention?
    meme_risk: str            # "LOW" | "MEDIUM" | "HIGH"
    
    # Congress Trades
    congress_trades: list     # Recent trades by politicians
    congress_net_sentiment: float  # -1.0 (selling) to +1.0 (buying)
    
    # Insider Trades
    insider_trades: list      # Recent insider transactions
    insider_net_sentiment: float  # -1.0 (selling) to +1.0 (buying)
    
    # Dark Pool
    dark_pool_ratio: float    # Off-exchange volume ratio
    dark_pool_signal: str     # "ACCUMULATION" | "DISTRIBUTION" | "NEUTRAL"
    
    # Metadata
    data_timestamp: str
    api_calls_used: int


class SocialSentimentSignal:
    """
    Social sentiment signal using Quiver Quant API.
    
    Tracks:
    - WallStreetBets mentions and sentiment
    - Congress trading activity
    - Insider transactions
    - Dark pool / off-exchange volume
    """
    
    BASE_URL = "https://api.quiverquant.com/beta"
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json"
        }
        self.api_calls_today = 0
        self.cache = {}  # Simple cache to avoid repeated calls
        self.cache_ttl = 300  # 5 minute cache
    
    # =========================================================================
    # MAIN ENTRY POINT
    # =========================================================================
    
    def get_signal(self, ticker: str) -> SocialSignal:
        """
        Get complete social sentiment signal for a ticker.
        
        Args:
            ticker: Stock ticker (e.g., "TSLA", "NVDA")
        
        Returns:
            SocialSignal with all sentiment data
        """
        
        print(f"📱 Getting social signal for {ticker}...")
        
        # Get all data sources
        wsb_data = self._get_wsb_data(ticker)
        congress_data = self._get_congress_data(ticker)
        insider_data = self._get_insider_data(ticker)
        darkpool_data = self._get_darkpool_data(ticker)
        
        # Calculate component scores
        wsb_score = self._calculate_wsb_score(wsb_data)
        congress_score = self._calculate_congress_score(congress_data)
        insider_score = self._calculate_insider_score(insider_data)
        darkpool_score = self._calculate_darkpool_score(darkpool_data)
        
        # Weighted combination
        # WSB: 30%, Congress: 25%, Insider: 25%, Dark Pool: 20%
        final_score = (
            0.30 * wsb_score +
            0.25 * congress_score +
            0.25 * insider_score +
            0.20 * darkpool_score
        )
        
        # Determine direction
        if final_score > 0.2:
            direction = "BULLISH"
        elif final_score < -0.2:
            direction = "BEARISH"
        else:
            direction = "NEUTRAL"
        
        # Calculate confidence based on data availability
        data_points = sum([
            1 if wsb_data else 0,
            1 if congress_data else 0,
            1 if insider_data else 0,
            1 if darkpool_data else 0
        ])
        confidence = int((data_points / 4) * 100 * min(1.0, abs(final_score) * 2 + 0.5))
        
        # Detect meme status
        wsb_rank = wsb_data.get("rank") or 999  # Default to 999 if None
        is_memeing = wsb_data.get("mentions_24h", 0) > 100 or wsb_rank < 20
        if is_memeing and wsb_data.get("mentions_24h", 0) > 500:
            meme_risk = "HIGH"
        elif is_memeing:
            meme_risk = "MEDIUM"
        else:
            meme_risk = "LOW"
        
        return SocialSignal(
            score=round(final_score, 3),
            direction=direction,
            confidence=confidence,
            wsb_mentions_24h=wsb_data.get("mentions_24h", 0),
            wsb_mentions_7d=wsb_data.get("mentions_7d", 0),
            wsb_rank=wsb_data.get("rank"),
            wsb_sentiment=round(wsb_score, 3),
            is_memeing=is_memeing,
            meme_risk=meme_risk,
            congress_trades=congress_data.get("trades", [])[:5],  # Top 5
            congress_net_sentiment=round(congress_score, 3),
            insider_trades=insider_data.get("trades", [])[:5],  # Top 5
            insider_net_sentiment=round(insider_score, 3),
            dark_pool_ratio=darkpool_data.get("ratio", 0),
            dark_pool_signal=self._interpret_darkpool(darkpool_score),
            data_timestamp=datetime.now().isoformat(),
            api_calls_used=self.api_calls_today
        )
    
    # =========================================================================
    # WALLSTREETBETS
    # =========================================================================
    
    def _get_wsb_data(self, ticker: str) -> dict:
        """Get WallStreetBets mention data."""
        
        cache_key = f"wsb_{ticker}"
        if self._is_cached(cache_key):
            return self.cache[cache_key]["data"]
        
        try:
            # Get ticker-specific data
            url = f"{self.BASE_URL}/historical/wallstreetbets/{ticker}"
            response = requests.get(url, headers=self.headers, timeout=10)
            self.api_calls_today += 1
            
            if response.status_code == 200:
                data = response.json()
                
                if data:
                    # Get recent mentions
                    recent = data[-7:] if len(data) >= 7 else data  # Last 7 days
                    
                    mentions_24h = data[-1].get("Mentions", 0) if data else 0
                    mentions_7d = sum(d.get("Mentions", 0) for d in recent)
                    rank = data[-1].get("Rank", None) if data else None
                    
                    result = {
                        "mentions_24h": mentions_24h,
                        "mentions_7d": mentions_7d,
                        "rank": rank,
                        "raw_data": recent
                    }
                    
                    self._set_cache(cache_key, result)
                    return result
            
            return {"mentions_24h": 0, "mentions_7d": 0, "rank": None}
            
        except Exception as e:
            print(f"   ⚠️ WSB API error: {e}")
            return {"mentions_24h": 0, "mentions_7d": 0, "rank": None}
    
    def _calculate_wsb_score(self, data: dict) -> float:
        """
        Calculate WSB sentiment score.
        
        Logic:
        - High mentions + improving rank = bullish retail interest
        - Extreme mentions = potential top (contrarian bearish)
        - Low mentions = neutral
        """
        
        mentions_24h = data.get("mentions_24h", 0)
        mentions_7d = data.get("mentions_7d", 0)
        rank = data.get("rank")
        
        # No data = neutral
        if mentions_7d == 0:
            return 0.0
        
        # Calculate momentum (24h vs 7d average)
        avg_daily = mentions_7d / 7
        if avg_daily > 0:
            momentum = (mentions_24h - avg_daily) / avg_daily
        else:
            momentum = 0
        
        # Base score from rank (lower rank = more bullish)
        if rank and rank < 10:
            rank_score = 0.5
        elif rank and rank < 25:
            rank_score = 0.3
        elif rank and rank < 50:
            rank_score = 0.1
        else:
            rank_score = 0.0
        
        # Momentum adjustment
        momentum_score = max(-0.5, min(0.5, momentum * 0.3))
        
        # CONTRARIAN: Extreme mentions can be a sell signal
        if mentions_24h > 1000:
            # Mania territory - potential top
            contrarian_adj = -0.3
        elif mentions_24h > 500:
            contrarian_adj = -0.1
        else:
            contrarian_adj = 0
        
        score = rank_score + momentum_score + contrarian_adj
        return max(-1.0, min(1.0, score))
    
    # =========================================================================
    # CONGRESS TRADING
    # =========================================================================
    
    def _get_congress_data(self, ticker: str) -> dict:
        """Get Congress trading data."""
        
        cache_key = f"congress_{ticker}"
        if self._is_cached(cache_key):
            return self.cache[cache_key]["data"]
        
        try:
            url = f"{self.BASE_URL}/historical/congresstrading/{ticker}"
            response = requests.get(url, headers=self.headers, timeout=10)
            self.api_calls_today += 1
            
            if response.status_code == 200:
                data = response.json()
                
                if data:
                    # Filter to recent trades (last 90 days)
                    cutoff = datetime.now() - timedelta(days=90)
                    recent_trades = []
                    
                    for trade in data:
                        trade_date = trade.get("TransactionDate", "")
                        if trade_date:
                            try:
                                dt = datetime.strptime(trade_date[:10], "%Y-%m-%d")
                                if dt >= cutoff:
                                    recent_trades.append({
                                        "politician": trade.get("Representative", "Unknown"),
                                        "party": trade.get("Party", ""),
                                        "action": trade.get("Transaction", ""),
                                        "amount": trade.get("Amount", ""),
                                        "date": trade_date[:10]
                                    })
                            except:
                                pass
                    
                    result = {"trades": recent_trades}
                    self._set_cache(cache_key, result)
                    return result
            
            return {"trades": []}
            
        except Exception as e:
            print(f"   ⚠️ Congress API error: {e}")
            return {"trades": []}
    
    def _calculate_congress_score(self, data: dict) -> float:
        """
        Calculate Congress trading sentiment.
        
        Logic:
        - Net buying = bullish (politicians have alpha)
        - Net selling = bearish
        - Weight by recency and amount
        """
        
        trades = data.get("trades", [])
        
        if not trades:
            return 0.0
        
        buy_count = 0
        sell_count = 0
        
        for trade in trades:
            action = trade.get("action", "").lower()
            
            if "purchase" in action or "buy" in action:
                buy_count += 1
            elif "sale" in action or "sell" in action:
                sell_count += 1
        
        total = buy_count + sell_count
        if total == 0:
            return 0.0
        
        # Net sentiment
        score = (buy_count - sell_count) / total
        
        # Boost for more data points (higher confidence)
        confidence_mult = min(1.0, total / 5)  # Max confidence at 5+ trades
        
        return score * confidence_mult
    
    # =========================================================================
    # INSIDER TRADING
    # =========================================================================
    
    def _get_insider_data(self, ticker: str) -> dict:
        """Get insider trading data (SEC Form 4 filings)."""
        
        cache_key = f"insider_{ticker}"
        if self._is_cached(cache_key):
            return self.cache[cache_key]["data"]
        
        try:
            url = f"{self.BASE_URL}/historical/insiders/{ticker}"
            response = requests.get(url, headers=self.headers, timeout=10)
            self.api_calls_today += 1
            
            if response.status_code == 200:
                data = response.json()
                
                if data:
                    # Filter to recent trades (last 90 days)
                    cutoff = datetime.now() - timedelta(days=90)
                    recent_trades = []
                    
                    for trade in data:
                        trade_date = trade.get("Date", "")
                        if trade_date:
                            try:
                                dt = datetime.strptime(trade_date[:10], "%Y-%m-%d")
                                if dt >= cutoff:
                                    recent_trades.append({
                                        "insider": trade.get("Name", "Unknown"),
                                        "title": trade.get("Title", ""),
                                        "action": trade.get("AcquiredDisposed", ""),
                                        "shares": trade.get("Shares", 0),
                                        "value": trade.get("Value", 0),
                                        "date": trade_date[:10]
                                    })
                            except:
                                pass
                    
                    result = {"trades": recent_trades}
                    self._set_cache(cache_key, result)
                    return result
            
            return {"trades": []}
            
        except Exception as e:
            print(f"   ⚠️ Insider API error: {e}")
            return {"trades": []}
    
    def _calculate_insider_score(self, data: dict) -> float:
        """
        Calculate insider trading sentiment.
        
        Logic:
        - Net buying by insiders = very bullish (they know the company)
        - Net selling = bearish (but could just be diversification)
        - CEO/CFO trades weighted more heavily
        """
        
        trades = data.get("trades", [])
        
        if not trades:
            return 0.0
        
        buy_value = 0
        sell_value = 0
        
        for trade in trades:
            action = trade.get("action", "").upper()
            value = trade.get("value", 0) or 0
            title = trade.get("title", "").upper()
            
            # Weight C-suite trades more heavily
            if "CEO" in title or "CFO" in title or "CHIEF" in title:
                weight = 2.0
            elif "DIRECTOR" in title:
                weight = 1.5
            else:
                weight = 1.0
            
            if action == "A":  # Acquired
                buy_value += value * weight
            elif action == "D":  # Disposed
                sell_value += value * weight
        
        total = buy_value + sell_value
        if total == 0:
            return 0.0
        
        # Net sentiment (buys are more meaningful than sells)
        if buy_value > sell_value:
            score = (buy_value - sell_value) / total
        else:
            # Selling is less bearish (could be normal diversification)
            score = (buy_value - sell_value) / total * 0.5
        
        return max(-1.0, min(1.0, score))
    
    # =========================================================================
    # DARK POOL / OFF-EXCHANGE VOLUME
    # =========================================================================
    
    def _get_darkpool_data(self, ticker: str) -> dict:
        """Get dark pool / off-exchange volume data."""
        
        cache_key = f"darkpool_{ticker}"
        if self._is_cached(cache_key):
            return self.cache[cache_key]["data"]
        
        try:
            url = f"{self.BASE_URL}/historical/offexchange/{ticker}"
            response = requests.get(url, headers=self.headers, timeout=10)
            self.api_calls_today += 1
            
            if response.status_code == 200:
                data = response.json()
                
                if data:
                    # Get recent data
                    recent = data[-5:] if len(data) >= 5 else data  # Last 5 days
                    
                    # Calculate average dark pool ratio
                    ratios = []
                    for d in recent:
                        short_vol = d.get("ShortVolume", 0)
                        total_vol = d.get("TotalVolume", 1)
                        if total_vol > 0:
                            ratios.append(short_vol / total_vol)
                    
                    avg_ratio = sum(ratios) / len(ratios) if ratios else 0
                    
                    result = {
                        "ratio": avg_ratio,
                        "raw_data": recent
                    }
                    
                    self._set_cache(cache_key, result)
                    return result
            
            return {"ratio": 0}
            
        except Exception as e:
            print(f"   ⚠️ Dark pool API error: {e}")
            return {"ratio": 0}
    
    def _calculate_darkpool_score(self, data: dict) -> float:
        """
        Calculate dark pool signal.
        
        Logic:
        - High short volume ratio (>50%) = potential bearish pressure
        - Low short volume ratio (<30%) = potential accumulation
        - Normal (30-50%) = neutral
        """
        
        ratio = data.get("ratio", 0)
        
        if ratio == 0:
            return 0.0
        
        # Interpret ratio
        # Note: "short volume" in dark pools doesn't always mean bearish
        # It's complex - often market makers shorting for hedging
        
        if ratio > 0.6:
            # Very high - could indicate selling pressure
            return -0.3
        elif ratio > 0.5:
            # Elevated
            return -0.1
        elif ratio < 0.3:
            # Low - potential accumulation
            return 0.2
        else:
            # Normal range
            return 0.0
    
    def _interpret_darkpool(self, score: float) -> str:
        """Convert dark pool score to signal."""
        if score > 0.1:
            return "ACCUMULATION"
        elif score < -0.1:
            return "DISTRIBUTION"
        else:
            return "NEUTRAL"
    
    # =========================================================================
    # CACHE HELPERS
    # =========================================================================
    
    def _is_cached(self, key: str) -> bool:
        """Check if data is cached and not expired."""
        if key not in self.cache:
            return False
        
        cached = self.cache[key]
        age = (datetime.now() - cached["timestamp"]).total_seconds()
        return age < self.cache_ttl
    
    def _set_cache(self, key: str, data: dict):
        """Cache data with timestamp."""
        self.cache[key] = {
            "data": data,
            "timestamp": datetime.now()
        }
    
    def clear_cache(self):
        """Clear all cached data."""
        self.cache = {}
    
    def get_api_usage(self) -> dict:
        """Get API usage stats."""
        return {
            "calls_today": self.api_calls_today,
            "cache_size": len(self.cache)
        }


# =============================================================================
# QUICK TEST
# =============================================================================

if __name__ == "__main__":
    import sys
    sys.path.insert(0, "/home/claude/lauren_v9")
    
    from config.credentials import QUIVER_QUANT_KEY
    
    if not QUIVER_QUANT_KEY:
        print("❌ No Quiver Quant API key configured")
        exit(1)
    
    social = SocialSentimentSignal(QUIVER_QUANT_KEY)
    
    # Test with Tesla
    print("\n" + "="*60)
    print("TESTING SOCIAL SIGNAL: TSLA")
    print("="*60)
    
    signal = social.get_signal("TSLA")
    
    print(f"\n📊 RESULTS:")
    print(f"   Overall Score: {signal.score}")
    print(f"   Direction: {signal.direction}")
    print(f"   Confidence: {signal.confidence}%")
    print(f"\n   WSB Mentions (24h): {signal.wsb_mentions_24h}")
    print(f"   WSB Mentions (7d): {signal.wsb_mentions_7d}")
    print(f"   WSB Rank: {signal.wsb_rank}")
    print(f"   Is Memeing: {signal.is_memeing}")
    print(f"   Meme Risk: {signal.meme_risk}")
    print(f"\n   Congress Net: {signal.congress_net_sentiment}")
    print(f"   Congress Trades: {len(signal.congress_trades)}")
    print(f"\n   Insider Net: {signal.insider_net_sentiment}")
    print(f"   Insider Trades: {len(signal.insider_trades)}")
    print(f"\n   Dark Pool Ratio: {signal.dark_pool_ratio:.1%}")
    print(f"   Dark Pool Signal: {signal.dark_pool_signal}")
    print(f"\n   API Calls Used: {signal.api_calls_used}")
    
    # Test with NVDA too
    print("\n" + "="*60)
    print("TESTING SOCIAL SIGNAL: NVDA")
    print("="*60)
    
    signal2 = social.get_signal("NVDA")
    
    print(f"\n📊 RESULTS:")
    print(f"   Overall Score: {signal2.score}")
    print(f"   Direction: {signal2.direction}")
    print(f"   Confidence: {signal2.confidence}%")
    print(f"   WSB Mentions (24h): {signal2.wsb_mentions_24h}")
    print(f"   Is Memeing: {signal2.is_memeing}")
    print(f"   Congress Trades: {len(signal2.congress_trades)}")
    print(f"   Insider Trades: {len(signal2.insider_trades)}")
