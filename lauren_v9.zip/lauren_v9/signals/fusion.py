"""
LAUREN V9 - Signal Fusion
==========================
Combines all signals (quantum, research, flow, social) into a single trading decision.
"""

from dataclasses import dataclass
from typing import Optional
from config.settings import (
    SIGNAL_WEIGHTS,
    MIN_CONFIDENCE,
    CONFIDENCE_BOOST_ALIGNED,
    CONFIDENCE_PENALTY_CONFLICT,
    CONFIDENCE_PENALTY_MAJOR
)


@dataclass
class SignalComponent:
    """Individual signal component."""
    name: str
    score: float          # -1.0 to +1.0
    direction: str        # "LONG", "SHORT", "NEUTRAL"
    confidence: float     # 0-100
    weight: float         # 0.0-1.0
    available: bool       # Was this signal available?
    details: dict         # Additional signal-specific data


@dataclass
class FusedSignal:
    """Result of signal fusion."""
    final_score: float              # -1.0 to +1.0
    direction: str                  # "LONG", "SHORT", "NO_TRADE"
    confidence: float               # 0-100
    conflicts: list                 # List of conflict descriptions
    signal_alignment: str           # "ALIGNED", "PARTIAL", "CONFLICTING"
    components: dict                # Individual component scores
    take_trade: bool                # Final decision
    reasoning: str                  # Human-readable explanation
    position_size_multiplier: float # Adjustment to position size


class SignalFusion:
    """
    Combines multiple trading signals into a single decision.
    
    Signal weights (from settings):
    - Quantum: 40% - Mathematical mispricing
    - Research: 35% - News, catalysts, fundamentals
    - Flow: 15% - Options flow (smart money)
    - Social: 10% - Retail sentiment
    """
    
    def __init__(self):
        self.weights = SIGNAL_WEIGHTS
    
    def fuse(
        self,
        quantum: Optional[dict] = None,
        research: Optional[dict] = None,
        flow: Optional[dict] = None,
        social: Optional[dict] = None
    ) -> FusedSignal:
        """
        Fuse all available signals into a single trading decision.
        
        Args:
            quantum: Output from quantum score calculator
            research: Output from research agent
            flow: Output from options flow analyzer (if available)
            social: Output from social sentiment analyzer (if available)
        
        Returns:
            FusedSignal with final decision and reasoning
        """
        
        # Build component list
        components = []
        
        # Quantum signal (required)
        if quantum:
            components.append(SignalComponent(
                name="quantum",
                score=self._normalize_quantum_score(quantum.get("score", 0)),
                direction=quantum.get("direction", "NEUTRAL"),
                confidence=quantum.get("confidence", 50),
                weight=self.weights["quantum"],
                available=True,
                details=quantum
            ))
        else:
            # No quantum = no trade
            return self._no_trade("Quantum signal required but not available")
        
        # Research signal
        if research:
            components.append(SignalComponent(
                name="research",
                score=research.get("sentiment_score", 0),
                direction=self._sentiment_to_direction(research.get("sentiment_label", "NEUTRAL")),
                confidence=research.get("confidence_adjustment", 0) + 50,  # Normalize to 0-100
                weight=self.weights["research"],
                available=True,
                details=research
            ))
        else:
            components.append(SignalComponent(
                name="research",
                score=0,
                direction="NEUTRAL",
                confidence=0,
                weight=0,  # No weight if not available
                available=False,
                details={}
            ))
        
        # Flow signal (optional)
        if flow and flow.get("available", False):
            components.append(SignalComponent(
                name="flow",
                score=flow.get("flow_score", 0),
                direction=flow.get("direction_bias", "NEUTRAL"),
                confidence=flow.get("confidence", 50),
                weight=self.weights["flow"],
                available=True,
                details=flow
            ))
        else:
            components.append(SignalComponent(
                name="flow",
                score=0,
                direction="NEUTRAL",
                confidence=0,
                weight=0,
                available=False,
                details={}
            ))
        
        # Social signal (optional) - from SocialSentimentSignal
        if social:
            # Handle both dict and SocialSignal dataclass
            if hasattr(social, 'score'):
                # It's a SocialSignal dataclass
                social_score = social.score
                social_direction = social.direction
                social_confidence = social.confidence
                social_details = {
                    "wsb_mentions_24h": social.wsb_mentions_24h,
                    "wsb_rank": social.wsb_rank,
                    "is_memeing": social.is_memeing,
                    "meme_risk": social.meme_risk,
                    "congress_net": social.congress_net_sentiment,
                    "insider_net": social.insider_net_sentiment,
                    "dark_pool_signal": social.dark_pool_signal
                }
            else:
                # It's a dict
                social_score = social.get("score", 0)
                social_direction = social.get("direction", "NEUTRAL")
                social_confidence = social.get("confidence", 50)
                social_details = social
            
            # Map direction format
            if social_direction == "BULLISH":
                social_direction = "LONG"
            elif social_direction == "BEARISH":
                social_direction = "SHORT"
            
            components.append(SignalComponent(
                name="social",
                score=social_score,
                direction=social_direction,
                confidence=social_confidence,
                weight=self.weights["social"],
                available=True,
                details=social_details
            ))
        else:
            components.append(SignalComponent(
                name="social",
                score=0,
                direction="NEUTRAL",
                confidence=0,
                weight=0,
                available=False,
                details={}
            ))
        
        # Calculate weighted score
        total_weight = sum(c.weight for c in components if c.available)
        if total_weight == 0:
            return self._no_trade("No signals available")
        
        # Renormalize weights
        for c in components:
            if c.available:
                c.weight = c.weight / total_weight * (c.weight / self.weights.get(c.name, 0.25))
        
        weighted_score = sum(c.score * c.weight for c in components if c.available) / total_weight
        
        # Detect conflicts
        conflicts = self._detect_conflicts(components)
        
        # Determine direction from quantum (primary signal)
        quantum_component = next(c for c in components if c.name == "quantum")
        proposed_direction = quantum_component.direction
        
        # Calculate confidence
        base_confidence = quantum_component.confidence
        
        # Adjust for research
        research_component = next((c for c in components if c.name == "research" and c.available), None)
        if research_component:
            research_adj = research_component.details.get("confidence_adjustment", 0)
            base_confidence += research_adj
        
        # Adjust for conflicts
        if len(conflicts) == 0:
            confidence = base_confidence * CONFIDENCE_BOOST_ALIGNED
            alignment = "ALIGNED"
        elif len(conflicts) == 1:
            confidence = base_confidence * CONFIDENCE_PENALTY_CONFLICT
            alignment = "PARTIAL"
        else:
            confidence = base_confidence * CONFIDENCE_PENALTY_MAJOR
            alignment = "CONFLICTING"
        
        # Clamp confidence
        confidence = max(0, min(100, confidence))
        
        # Determine if we should trade
        take_trade = (
            confidence >= MIN_CONFIDENCE and
            proposed_direction != "NEUTRAL" and
            alignment != "CONFLICTING"
        )
        
        # Check for research veto
        if research_component:
            rec = research_component.details.get("recommendation", "TAKE")
            if rec == "STRONG_SKIP":
                take_trade = False
            elif rec == "SKIP" and confidence < 70:
                take_trade = False
        
        # Position size multiplier
        size_mult = 1.0
        if research_component:
            size_mult = research_component.details.get("position_size_adjustment", 1.0)
        if alignment == "PARTIAL":
            size_mult *= 0.8
        
        # Build reasoning
        reasoning = self._build_reasoning(
            components=components,
            proposed_direction=proposed_direction,
            confidence=confidence,
            conflicts=conflicts,
            take_trade=take_trade
        )
        
        # Build component dict for output
        component_dict = {
            c.name: {
                "score": c.score,
                "direction": c.direction,
                "confidence": c.confidence,
                "weight": c.weight,
                "available": c.available
            }
            for c in components
        }
        
        return FusedSignal(
            final_score=weighted_score,
            direction=proposed_direction if take_trade else "NO_TRADE",
            confidence=confidence,
            conflicts=conflicts,
            signal_alignment=alignment,
            components=component_dict,
            take_trade=take_trade,
            reasoning=reasoning,
            position_size_multiplier=size_mult
        )
    
    def _normalize_quantum_score(self, score: float) -> float:
        """Normalize quantum score (-2 to +2) to (-1 to +1)."""
        return max(-1.0, min(1.0, score / 2))
    
    def _sentiment_to_direction(self, sentiment: str) -> str:
        """Convert sentiment label to direction."""
        if sentiment in ["VERY_BULLISH", "BULLISH"]:
            return "LONG"
        elif sentiment in ["VERY_BEARISH", "BEARISH"]:
            return "SHORT"
        return "NEUTRAL"
    
    def _detect_conflicts(self, components: list) -> list:
        """Detect conflicts between signals."""
        conflicts = []
        
        # Get available components with non-neutral directions
        active = [c for c in components if c.available and c.direction != "NEUTRAL"]
        
        if len(active) < 2:
            return conflicts
        
        # Compare each pair
        for i, c1 in enumerate(active):
            for c2 in active[i+1:]:
                if c1.direction != c2.direction:
                    conflicts.append({
                        "signal_a": c1.name,
                        "signal_b": c2.name,
                        "description": f"{c1.name} says {c1.direction} but {c2.name} says {c2.direction}"
                    })
        
        return conflicts
    
    def _build_reasoning(
        self,
        components: list,
        proposed_direction: str,
        confidence: float,
        conflicts: list,
        take_trade: bool
    ) -> str:
        """Build human-readable reasoning."""
        
        parts = []
        
        # Start with quantum
        quantum = next(c for c in components if c.name == "quantum")
        parts.append(f"Quantum: {quantum.direction} ({quantum.confidence:.0f}% conf)")
        
        # Add research
        research = next((c for c in components if c.name == "research" and c.available), None)
        if research:
            sentiment = research.details.get("sentiment_label", "NEUTRAL")
            key_news = research.details.get("key_news", "")
            parts.append(f"Research: {sentiment}")
            if key_news:
                parts.append(f"News: {key_news[:50]}...")
        
        # Add conflicts
        if conflicts:
            parts.append(f"⚠️ {len(conflicts)} conflict(s) detected")
        
        # Final decision
        if take_trade:
            parts.append(f"✅ TAKING {proposed_direction} trade ({confidence:.0f}% confidence)")
        else:
            parts.append(f"❌ SKIPPING trade (confidence: {confidence:.0f}%)")
        
        return " | ".join(parts)
    
    def _no_trade(self, reason: str) -> FusedSignal:
        """Return a no-trade signal."""
        return FusedSignal(
            final_score=0,
            direction="NO_TRADE",
            confidence=0,
            conflicts=[],
            signal_alignment="N/A",
            components={},
            take_trade=False,
            reasoning=reason,
            position_size_multiplier=0
        )


# =============================================================================
# QUICK TEST
# =============================================================================

if __name__ == "__main__":
    fusion = SignalFusion()
    
    # Test case: Quantum SHORT but research BULLISH (conflict)
    result = fusion.fuse(
        quantum={
            "score": 0.52,
            "direction": "SHORT",
            "confidence": 72
        },
        research={
            "sentiment_score": 0.65,
            "sentiment_label": "BULLISH",
            "confidence_adjustment": 10,
            "key_news": "Tesla beats Q4 deliveries",
            "recommendation": "SKIP",
            "position_size_adjustment": 0.6
        }
    )
    
    print("FUSION TEST - Quantum SHORT vs Research BULLISH:")
    print(f"  Direction: {result.direction}")
    print(f"  Confidence: {result.confidence:.0f}%")
    print(f"  Alignment: {result.signal_alignment}")
    print(f"  Take trade: {result.take_trade}")
    print(f"  Conflicts: {result.conflicts}")
    print(f"  Reasoning: {result.reasoning}")
