"""
LAUREN V9 - Research Agent
===========================
Autonomous research capability that can search the web, read articles,
and synthesize information to make trading decisions.

This is the "brain" that thinks before trading.
"""

import json
import requests
from typing import Optional
from datetime import datetime, timedelta


class ResearchAgent:
    """
    Autonomous research agent for LAUREN v9.
    
    Capabilities:
    - Generate intelligent search queries based on trading context
    - Search the web using Serper API
    - Read and parse web pages using Jina Reader (free)
    - Synthesize research into actionable trading signals
    - Detect conflicts between quantitative signals and fundamental reality
    """
    
    def __init__(self, claude_key: str, serper_key: str):
        self.claude_key = claude_key
        self.serper_key = serper_key
        self.claude_model = "claude-sonnet-4-20250514"
        
        # Research configuration
        self.max_searches_per_ticker = 6
        self.max_pages_to_read = 3
        self.search_timeout = 10
        self.read_timeout = 15
        
        # Token tracking for cost monitoring
        self.tokens_used_today = 0
        self.searches_used_today = 0
    
    # =========================================================================
    # CORE RESEARCH FLOW
    # =========================================================================
    
    def research_trade(
        self,
        ticker: str,
        underlying: str,
        direction: str,
        quantum_score: float,
        quantum_confidence: float,
        current_price: float,
        strike: float,
        expiry: str,
        option_type: str = "CALL"
    ) -> dict:
        """
        Full research flow for a potential trade.
        
        1. Generate smart search queries
        2. Search the web
        3. Read most relevant articles
        4. Synthesize into trading signal
        5. Return recommendation
        
        Args:
            ticker: Leveraged ETF ticker (e.g., "TSLL", "NVDL")
            underlying: Underlying stock (e.g., "TSLA", "NVDA")
            direction: Proposed direction from quantum score ("LONG" or "SHORT")
            quantum_score: Raw quantum score (-2 to +2)
            quantum_confidence: Confidence level (0-100)
            current_price: Current option price
            strike: Strike price
            expiry: Expiration date (YYYY-MM-DD)
            option_type: "CALL" or "PUT"
        
        Returns:
            Research synthesis with trade recommendation
        """
        
        print(f"\n{'='*60}")
        print(f"🔍 RESEARCHING: {ticker} {strike} {option_type} ({direction})")
        print(f"{'='*60}")
        
        # Step 1: Generate search queries
        queries = self._generate_queries(
            ticker=ticker,
            underlying=underlying,
            direction=direction
        )
        print(f"📋 Generated {len(queries)} search queries")
        
        # Step 2: Execute searches
        all_results = []
        for query in queries[:self.max_searches_per_ticker]:
            results = self._search(query)
            if results:
                all_results.extend(results)
                print(f"   ✓ '{query}' → {len(results)} results")
            else:
                print(f"   ✗ '{query}' → no results")
        
        if not all_results:
            print("⚠️ No search results found")
            return self._no_research_result(direction, quantum_confidence)
        
        # Step 3: Select and read best sources
        urls_to_read = self._select_best_sources(all_results)
        print(f"📖 Reading {len(urls_to_read)} articles...")
        
        articles = []
        for url in urls_to_read[:self.max_pages_to_read]:
            content = self._read_page(url)
            if content:
                articles.append({"url": url, "content": content})
                print(f"   ✓ Read: {url[:60]}...")
        
        # Step 4: Synthesize everything
        print("🧠 Synthesizing research...")
        synthesis = self._synthesize(
            ticker=ticker,
            underlying=underlying,
            direction=direction,
            quantum_score=quantum_score,
            quantum_confidence=quantum_confidence,
            current_price=current_price,
            strike=strike,
            expiry=expiry,
            option_type=option_type,
            search_results=all_results,
            articles=articles
        )
        
        # Log decision
        self._log_research(ticker, direction, synthesis)
        
        return synthesis
    
    # =========================================================================
    # QUERY GENERATION
    # =========================================================================
    
    def _generate_queries(self, ticker: str, underlying: str, direction: str) -> list:
        """
        Use Claude to generate intelligent search queries.
        """
        
        today = datetime.now().strftime("%B %d %Y")
        
        prompt = f"""You are a trading research assistant. Generate search queries to research a potential options trade.

TRADE CONTEXT:
- Ticker: {ticker} (leveraged ETF tracking {underlying})
- Underlying: {underlying}
- Proposed direction: {direction}
- Today's date: {today}

Generate 6 search queries that would help determine if this trade is a good idea.
Focus on:
1. Recent news about the underlying company
2. Upcoming catalysts (earnings, FDA, product launches, etc.)
3. Analyst activity (upgrades, downgrades, price targets)
4. Options flow and unusual activity
5. Social sentiment (if relevant)
6. Any risk factors or headwinds

Return ONLY a JSON array of strings, no other text:
["query 1", "query 2", ...]

Make queries specific and current. Include the company name and dates where relevant."""

        try:
            response = self._call_claude(prompt, max_tokens=500)
            queries = json.loads(response)
            return queries
        except Exception as e:
            print(f"Query generation error: {e}")
            # Fallback to hardcoded queries
            return self._fallback_queries(underlying)
    
    def _fallback_queries(self, underlying: str) -> list:
        """Fallback queries if Claude fails."""
        today = datetime.now().strftime("%B %d %Y")
        return [
            f"{underlying} stock news today",
            f"{underlying} earnings date 2025",
            f"{underlying} analyst ratings",
            f"{underlying} stock price today",
            f"{underlying} options unusual activity",
            f"{underlying} company news {today}"
        ]
    
    # =========================================================================
    # WEB SEARCH (Serper API)
    # =========================================================================
    
    def _search(self, query: str) -> list:
        """
        Search the web using Serper API.
        Returns list of {title, link, snippet} dicts.
        """
        
        url = "https://google.serper.dev/search"
        
        headers = {
            "X-API-KEY": self.serper_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "q": query,
            "num": 5,  # Top 5 results per query
            "gl": "us",
            "hl": "en"
        }
        
        try:
            response = requests.post(
                url,
                headers=headers,
                json=payload,
                timeout=self.search_timeout
            )
            response.raise_for_status()
            
            data = response.json()
            self.searches_used_today += 1
            
            results = []
            for item in data.get("organic", []):
                results.append({
                    "title": item.get("title", ""),
                    "link": item.get("link", ""),
                    "snippet": item.get("snippet", ""),
                    "date": item.get("date", "")
                })
            
            return results
            
        except Exception as e:
            print(f"Search error for '{query}': {e}")
            return []
    
    # =========================================================================
    # WEB READING (Jina Reader - Free)
    # =========================================================================
    
    def _read_page(self, url: str) -> Optional[str]:
        """
        Read a web page using Jina Reader (free, no API key needed).
        Returns cleaned markdown content.
        """
        
        jina_url = f"https://r.jina.ai/{url}"
        
        try:
            response = requests.get(
                jina_url,
                timeout=self.read_timeout,
                headers={"Accept": "text/plain"}
            )
            response.raise_for_status()
            
            content = response.text
            
            # Truncate if too long (keep first 4000 chars)
            if len(content) > 4000:
                content = content[:4000] + "\n\n[TRUNCATED]"
            
            return content
            
        except Exception as e:
            print(f"Read error for '{url}': {e}")
            return None
    
    def _select_best_sources(self, results: list) -> list:
        """
        Select the best URLs to read from search results.
        Prioritize financial news sources.
        """
        
        # Priority domains
        priority_domains = [
            "reuters.com", "bloomberg.com", "wsj.com", "cnbc.com",
            "marketwatch.com", "seekingalpha.com", "barrons.com",
            "fool.com", "investopedia.com", "finance.yahoo.com",
            "thestreet.com", "benzinga.com", "investors.com"
        ]
        
        # Score each result
        scored = []
        seen_urls = set()
        
        for r in results:
            url = r.get("link", "")
            if url in seen_urls:
                continue
            seen_urls.add(url)
            
            score = 0
            
            # Priority domain boost
            for domain in priority_domains:
                if domain in url:
                    score += 10
                    break
            
            # Has date = recent = good
            if r.get("date"):
                score += 5
            
            # Longer snippet = more content
            snippet_len = len(r.get("snippet", ""))
            score += min(snippet_len / 50, 5)
            
            scored.append((score, url))
        
        # Sort by score descending
        scored.sort(key=lambda x: x[0], reverse=True)
        
        return [url for score, url in scored[:self.max_pages_to_read]]
    
    # =========================================================================
    # SYNTHESIS (Claude analyzes everything)
    # =========================================================================
    
    def _synthesize(
        self,
        ticker: str,
        underlying: str,
        direction: str,
        quantum_score: float,
        quantum_confidence: float,
        current_price: float,
        strike: float,
        expiry: str,
        option_type: str,
        search_results: list,
        articles: list
    ) -> dict:
        """
        Use Claude to synthesize all research into a trading decision.
        """
        
        # Format search results
        search_summary = "\n".join([
            f"- {r['title']}: {r['snippet']}"
            for r in search_results[:15]
        ])
        
        # Format articles
        article_summary = "\n\n---\n\n".join([
            f"SOURCE: {a['url']}\n\n{a['content']}"
            for a in articles
        ])
        
        today = datetime.now().strftime("%Y-%m-%d")
        
        prompt = f"""You are an expert options trading analyst. Analyze this research and provide a trading recommendation.

TRADE BEING CONSIDERED:
- Ticker: {ticker} (2x leveraged ETF tracking {underlying})
- Option: {strike} {option_type} expiring {expiry}
- Current option price: ${current_price:.2f}
- Proposed direction: {direction} (based on mathematical mispricing)
- Quantum score: {quantum_score:.2f} (positive = overpriced, negative = underpriced)
- Quantum confidence: {quantum_confidence:.0f}%
- Today's date: {today}

SEARCH RESULTS:
{search_summary}

FULL ARTICLES:
{article_summary}

ANALYSIS REQUIRED:
1. What is the current sentiment around {underlying}?
2. Are there any upcoming catalysts (earnings, FDA, product launches)?
3. Does the fundamental picture support or conflict with the {direction} signal?
4. What are the key risk factors?
5. Should we take this trade, skip it, or wait?

RESPOND WITH ONLY THIS JSON (no other text):
{{
    "sentiment_score": <float from -1.0 (very bearish) to +1.0 (very bullish)>,
    "sentiment_label": "<VERY_BEARISH|BEARISH|NEUTRAL|BULLISH|VERY_BULLISH>",
    "catalyst_detected": <true|false>,
    "catalyst_type": "<type or null>",
    "catalyst_date": "<YYYY-MM-DD or null>",
    "catalyst_strength": <1-10>,
    "earnings_within_7_days": <true|false>,
    "earnings_date": "<YYYY-MM-DD or null>",
    "analyst_sentiment": "<summary of analyst activity>",
    "key_news": "<one sentence summary of most important news>",
    "risk_factors": ["<risk 1>", "<risk 2>"],
    "supports_direction": <true|false>,
    "conflict_detected": <true|false>,
    "conflict_reason": "<why the research conflicts with the trade or null>",
    "recommendation": "<STRONG_TAKE|TAKE|SKIP|STRONG_SKIP>",
    "confidence_adjustment": <float from -30 to +30, how much to adjust confidence>,
    "position_size_adjustment": <float from 0.5 to 1.5, multiplier for position size>,
    "reasoning": "<2-3 sentence explanation of your recommendation>"
}}

Be decisive. If the research clearly supports or opposes the trade, say so."""

        try:
            response = self._call_claude(prompt, max_tokens=1000)
            
            # Clean response (sometimes Claude adds backticks)
            response = response.strip()
            if response.startswith("```"):
                response = response.split("```")[1]
                if response.startswith("json"):
                    response = response[4:]
            response = response.strip()
            
            synthesis = json.loads(response)
            
            # Add metadata
            synthesis["research_timestamp"] = datetime.now().isoformat()
            synthesis["queries_used"] = self.searches_used_today
            synthesis["articles_read"] = len(articles)
            
            return synthesis
            
        except Exception as e:
            print(f"Synthesis error: {e}")
            return self._no_research_result(direction, quantum_confidence)
    
    # =========================================================================
    # CLAUDE API
    # =========================================================================
    
    def _call_claude(self, prompt: str, max_tokens: int = 500) -> str:
        """
        Call Claude API.
        """
        
        url = "https://api.anthropic.com/v1/messages"
        
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.claude_key,
            "anthropic-version": "2023-06-01"
        }
        
        payload = {
            "model": self.claude_model,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "user", "content": prompt}
            ]
        }
        
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        
        # Track tokens
        usage = data.get("usage", {})
        self.tokens_used_today += usage.get("input_tokens", 0)
        self.tokens_used_today += usage.get("output_tokens", 0)
        
        return data["content"][0]["text"]
    
    # =========================================================================
    # HELPERS
    # =========================================================================
    
    def _no_research_result(self, direction: str, confidence: float) -> dict:
        """Return when research fails or finds nothing."""
        return {
            "sentiment_score": 0.0,
            "sentiment_label": "NEUTRAL",
            "catalyst_detected": False,
            "catalyst_type": None,
            "catalyst_date": None,
            "catalyst_strength": 0,
            "earnings_within_7_days": False,
            "earnings_date": None,
            "analyst_sentiment": "No data",
            "key_news": "No recent news found",
            "risk_factors": ["Limited research data"],
            "supports_direction": True,  # Don't block trade just because research failed
            "conflict_detected": False,
            "conflict_reason": None,
            "recommendation": "TAKE",  # Default to quantum signal
            "confidence_adjustment": -10,  # Slight penalty for no research
            "position_size_adjustment": 0.8,  # Smaller size when uncertain
            "reasoning": "Research inconclusive. Proceeding with quantum signal but reduced confidence.",
            "research_timestamp": datetime.now().isoformat(),
            "queries_used": 0,
            "articles_read": 0
        }
    
    def _log_research(self, ticker: str, direction: str, synthesis: dict):
        """Log research decision for later analysis."""
        
        rec = synthesis.get("recommendation", "UNKNOWN")
        conf_adj = synthesis.get("confidence_adjustment", 0)
        reasoning = synthesis.get("reasoning", "")
        
        print(f"\n📊 RESEARCH RESULT for {ticker} {direction}:")
        print(f"   Recommendation: {rec}")
        print(f"   Confidence adjustment: {conf_adj:+.0f}")
        print(f"   Reasoning: {reasoning}")
        
        if synthesis.get("conflict_detected"):
            print(f"   ⚠️ CONFLICT: {synthesis.get('conflict_reason')}")
        
        if synthesis.get("catalyst_detected"):
            print(f"   🎯 CATALYST: {synthesis.get('catalyst_type')} on {synthesis.get('catalyst_date')}")
    
    def get_usage_stats(self) -> dict:
        """Get API usage stats for the day."""
        return {
            "searches_today": self.searches_used_today,
            "tokens_today": self.tokens_used_today,
            "estimated_cost": (self.tokens_used_today / 1000) * 0.003 + (self.searches_used_today * 0.0005)
        }
    
    def reset_daily_stats(self):
        """Reset daily counters (call at midnight)."""
        self.tokens_used_today = 0
        self.searches_used_today = 0


# =============================================================================
# QUICK TEST
# =============================================================================

if __name__ == "__main__":
    from config.credentials import CLAUDE_API_KEY, SERPER_API_KEY
    
    agent = ResearchAgent(
        claude_key=CLAUDE_API_KEY,
        serper_key=SERPER_API_KEY
    )
    
    # Test research on a fake trade
    result = agent.research_trade(
        ticker="TSLL",
        underlying="TSLA",
        direction="SHORT",
        quantum_score=0.52,
        quantum_confidence=72,
        current_price=1.25,
        strike=15.0,
        expiry="2025-01-17",
        option_type="CALL"
    )
    
    print("\n" + "="*60)
    print("FULL RESEARCH OUTPUT:")
    print("="*60)
    print(json.dumps(result, indent=2))
    
    print("\n" + "="*60)
    print("USAGE STATS:")
    print("="*60)
    print(json.dumps(agent.get_usage_stats(), indent=2))
