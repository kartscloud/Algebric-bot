"""
LAUREN V9 - Trading Agent
==========================
Autonomous trading agent that:
1. SEES - Scans option chains for mispriced opportunities
2. THINKS - Researches context, analyzes fundamentals
3. DECIDES - Fuses signals into trading decisions
4. ACTS - Executes trades with proper risk management
5. LEARNS - Logs outcomes for future improvement

This is the main brain of the system.
"""

import json
import time
import logging
from datetime import datetime, timedelta
from typing import Optional
from dataclasses import dataclass, asdict

# Internal imports
import sys
sys.path.insert(0, '/home/claude/lauren_v9')

from config.credentials import CLAUDE_API_KEY, SERPER_API_KEY
from config.settings import (
    ACTIVE_TICKERS, UNDERLYING_MAP, HISTORICAL_VOL,
    SHORT_THRESHOLD, LONG_THRESHOLD, MIN_CONFIDENCE,
    DTE_MIN, DTE_MAX, MIN_OTM, MAX_OTM,
    MIN_PREMIUM, MIN_BID, MIN_OPEN_INTEREST, MAX_SPREAD_PCT,
    PROFIT_TARGET_PCT, STOP_LOSS_PCT, MAX_LOSS_DOLLARS, MAX_POSITION_PCT,
    SCAN_INTERVAL
)
from agents.research_agent import ResearchAgent
from signals.fusion import SignalFusion


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class OptionCandidate:
    """A potential trading opportunity."""
    ticker: str
    underlying: str
    option_type: str      # "CALL" or "PUT"
    strike: float
    expiry: str           # YYYY-MM-DD
    dte: int
    current_price: float
    bid: float
    ask: float
    open_interest: int
    implied_vol: float
    delta: float
    gamma: float
    theta: float
    quantum_score: float
    quantum_direction: str
    quantum_confidence: float


@dataclass
class TradeDecision:
    """Final trade decision after research and fusion."""
    candidate: OptionCandidate
    take_trade: bool
    direction: str
    confidence: float
    position_size_dollars: float
    position_size_contracts: int
    entry_price: float
    target_price: float
    stop_price: float
    max_loss: float
    research_summary: dict
    fusion_result: dict
    reasoning: str
    timestamp: str


# =============================================================================
# TRADING AGENT
# =============================================================================

class TradingAgent:
    """
    Autonomous trading agent for LAUREN v9.
    
    Capabilities:
    - Scan option chains for mispriced opportunities
    - Research each opportunity using web search + Claude
    - Fuse multiple signals into trading decisions
    - Execute trades with risk management
    - Monitor and exit positions
    """
    
    def __init__(
        self,
        paper_mode: bool = True,
        buying_power: float = 10000,
        robin_api = None
    ):
        """
        Initialize the trading agent.
        
        Args:
            paper_mode: If True, simulates trades. If False, executes real trades.
            buying_power: Available capital for trading
            robin_api: Robinhood API client (required for live trading)
        """
        
        self.paper_mode = paper_mode
        self.buying_power = buying_power
        self.robin_api = robin_api
        
        # Initialize sub-agents
        self.research_agent = ResearchAgent(
            claude_key=CLAUDE_API_KEY,
            serper_key=SERPER_API_KEY
        )
        self.fusion = SignalFusion()
        
        # State
        self.positions = []
        self.trade_history = []
        self.daily_pnl = 0.0
        self.scan_count = 0
        
        # Logging
        self._setup_logging()
        
        self.logger.info("="*60)
        self.logger.info("LAUREN V9 TRADING AGENT INITIALIZED")
        self.logger.info(f"Mode: {'PAPER' if paper_mode else 'LIVE'}")
        self.logger.info(f"Buying Power: ${buying_power:,.2f}")
        self.logger.info(f"Tickers: {ACTIVE_TICKERS}")
        self.logger.info("="*60)
    
    def _setup_logging(self):
        """Set up logging."""
        self.logger = logging.getLogger("LAUREN_V9")
        self.logger.setLevel(logging.INFO)
        
        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)
    
    # =========================================================================
    # MAIN LOOP
    # =========================================================================
    
    def run(self):
        """
        Main agent loop. Runs continuously during market hours.
        """
        self.logger.info("Starting main agent loop...")
        
        while True:
            try:
                # Check if market is open
                if not self._is_market_open():
                    self.logger.info("Market closed. Sleeping...")
                    time.sleep(60)
                    continue
                
                # Run one scan cycle
                self.scan_cycle()
                
                # Wait for next cycle
                self.logger.info(f"Sleeping {SCAN_INTERVAL}s until next scan...")
                time.sleep(SCAN_INTERVAL)
                
            except KeyboardInterrupt:
                self.logger.info("Shutting down agent...")
                self._save_state()
                break
            except Exception as e:
                self.logger.error(f"Error in main loop: {e}")
                time.sleep(30)
    
    def scan_cycle(self):
        """
        One full scan cycle:
        1. Find mispriced options (quantum score)
        2. Research each candidate
        3. Fuse signals and decide
        4. Execute approved trades
        5. Monitor existing positions
        """
        
        self.scan_count += 1
        self.logger.info(f"\n{'='*60}")
        self.logger.info(f"SCAN CYCLE #{self.scan_count}")
        self.logger.info(f"{'='*60}")
        
        # Step 1: Find candidates
        candidates = self._find_candidates()
        self.logger.info(f"Found {len(candidates)} candidate(s)")
        
        # Step 2-4: Evaluate and trade each candidate
        for candidate in candidates:
            decision = self._evaluate_candidate(candidate)
            
            if decision.take_trade:
                self._execute_trade(decision)
        
        # Step 5: Monitor existing positions
        self._monitor_positions()
        
        # Log status
        self._log_status()
    
    # =========================================================================
    # STEP 1: FIND CANDIDATES (Quantum Score)
    # =========================================================================
    
    def _find_candidates(self) -> list:
        """
        Scan option chains and find mispriced opportunities.
        Returns list of OptionCandidate objects.
        """
        
        candidates = []
        
        for ticker in ACTIVE_TICKERS:
            underlying = UNDERLYING_MAP.get(ticker, ticker)
            
            self.logger.info(f"Scanning {ticker} ({underlying})...")
            
            # Get option chain (mock for now)
            chain = self._get_option_chain(ticker)
            
            if not chain:
                continue
            
            # Score each option
            for option in chain:
                # Apply filters
                if not self._passes_filters(option):
                    continue
                
                # Calculate quantum score
                score, direction, confidence = self._calculate_quantum_score(option, ticker)
                
                # Check if it's a signal
                if direction == "NEUTRAL":
                    continue
                
                # Create candidate
                candidate = OptionCandidate(
                    ticker=ticker,
                    underlying=underlying,
                    option_type=option.get("type", "CALL"),
                    strike=option.get("strike", 0),
                    expiry=option.get("expiry", ""),
                    dte=option.get("dte", 0),
                    current_price=option.get("price", 0),
                    bid=option.get("bid", 0),
                    ask=option.get("ask", 0),
                    open_interest=option.get("oi", 0),
                    implied_vol=option.get("iv", 0),
                    delta=option.get("delta", 0),
                    gamma=option.get("gamma", 0),
                    theta=option.get("theta", 0),
                    quantum_score=score,
                    quantum_direction=direction,
                    quantum_confidence=confidence
                )
                
                candidates.append(candidate)
                self.logger.info(f"  ✓ Candidate: {ticker} {option.get('strike')} {option.get('type')} | Score: {score:.2f} | Dir: {direction}")
        
        return candidates
    
    def _get_option_chain(self, ticker: str) -> list:
        """
        Get option chain for a ticker.
        In paper mode, returns mock data.
        In live mode, calls Robinhood API.
        """
        
        if self.paper_mode:
            # Return mock data for testing
            # In real implementation, this would call the broker API
            return self._mock_option_chain(ticker)
        
        # Live mode - call Robinhood
        # TODO: Implement Robinhood integration
        return []
    
    def _mock_option_chain(self, ticker: str) -> list:
        """Generate mock option chain for testing."""
        
        # Mock current prices
        prices = {
            "NVDL": 85.0,
            "TSLL": 18.0
        }
        
        current_price = prices.get(ticker, 50.0)
        
        # Generate some options
        options = []
        for dte in [7, 10, 14]:
            for pct in [-0.15, -0.10, -0.05, 0.05, 0.10, 0.15]:
                strike = round(current_price * (1 + pct), 0)
                
                # Mock IV (higher for further OTM)
                base_iv = HISTORICAL_VOL.get(ticker, 0.8)
                iv = base_iv * (1 + abs(pct) * 0.5)
                
                # Mock price (rough BS approximation)
                import math
                price = current_price * 0.1 * (1 - abs(pct)) * math.sqrt(dte / 365)
                price = max(0.15, round(price, 2))
                
                options.append({
                    "type": "CALL",
                    "strike": strike,
                    "expiry": (datetime.now() + timedelta(days=dte)).strftime("%Y-%m-%d"),
                    "dte": dte,
                    "price": price,
                    "bid": round(price * 0.95, 2),
                    "ask": round(price * 1.05, 2),
                    "oi": 100,
                    "iv": iv,
                    "delta": 0.4,
                    "gamma": 0.05,
                    "theta": -0.02
                })
        
        # Add one clearly overpriced option (SHORT signal) for testing
        if ticker == "TSLL":
            options.append({
                "type": "CALL",
                "strike": 20.0,
                "expiry": (datetime.now() + timedelta(days=10)).strftime("%Y-%m-%d"),
                "dte": 10,
                "price": 1.50,
                "bid": 1.40,
                "ask": 1.60,
                "oi": 500,
                "iv": 1.60,  # 160% IV vs 95% HV = massively overpriced
                "delta": 0.35,
                "gamma": 0.08,
                "theta": -0.03
            })
        
        return options
    
    def _passes_filters(self, option: dict) -> bool:
        """Check if option passes all filters."""
        
        dte = option.get("dte", 0)
        if dte < DTE_MIN or dte > DTE_MAX:
            return False
        
        price = option.get("price", 0)
        if price < MIN_PREMIUM:
            return False
        
        bid = option.get("bid", 0)
        if bid < MIN_BID:
            return False
        
        oi = option.get("oi", 0)
        if oi < MIN_OPEN_INTEREST:
            return False
        
        # Spread check
        ask = option.get("ask", 0)
        if bid > 0:
            spread_pct = (ask - bid) / bid
            if spread_pct > MAX_SPREAD_PCT:
                return False
        
        return True
    
    def _calculate_quantum_score(self, option: dict, ticker: str) -> tuple:
        """
        Calculate quantum score for an option.
        
        Returns: (score, direction, confidence)
        """
        
        iv = option.get("iv", 0.8)
        hv = HISTORICAL_VOL.get(ticker, 0.8)
        
        # Simple score: IV divergence
        # Positive = overpriced (SHORT signal)
        # Negative = underpriced (LONG signal)
        score = (iv - hv) / hv
        
        # Determine direction
        if score > SHORT_THRESHOLD:
            direction = "SHORT"
            confidence = min(95, 50 + (score - SHORT_THRESHOLD) * 100)
        elif score < LONG_THRESHOLD:
            direction = "LONG"
            confidence = min(95, 50 + abs(score - LONG_THRESHOLD) * 100)
        else:
            direction = "NEUTRAL"
            confidence = 0
        
        return (score, direction, confidence)
    
    # =========================================================================
    # STEP 2-3: EVALUATE CANDIDATE
    # =========================================================================
    
    def _evaluate_candidate(self, candidate: OptionCandidate) -> TradeDecision:
        """
        Evaluate a candidate by:
        1. Researching it (news, fundamentals)
        2. Fusing all signals
        3. Making a decision
        """
        
        self.logger.info(f"\n📊 Evaluating {candidate.ticker} {candidate.strike} {candidate.option_type}...")
        
        # Step 1: Research
        research = self.research_agent.research_trade(
            ticker=candidate.ticker,
            underlying=candidate.underlying,
            direction=candidate.quantum_direction,
            quantum_score=candidate.quantum_score,
            quantum_confidence=candidate.quantum_confidence,
            current_price=candidate.current_price,
            strike=candidate.strike,
            expiry=candidate.expiry,
            option_type=candidate.option_type
        )
        
        # Step 2: Fuse signals
        fusion_result = self.fusion.fuse(
            quantum={
                "score": candidate.quantum_score,
                "direction": candidate.quantum_direction,
                "confidence": candidate.quantum_confidence
            },
            research=research
        )
        
        # Step 3: Position sizing
        size_dollars, size_contracts, entry_price = self._calculate_position_size(
            candidate=candidate,
            fusion_result=fusion_result
        )
        
        # Calculate targets
        target_price = entry_price * (1 + PROFIT_TARGET_PCT)
        stop_price = entry_price * (1 - STOP_LOSS_PCT)
        max_loss = size_contracts * 100 * (entry_price - stop_price)
        
        # Build decision
        decision = TradeDecision(
            candidate=candidate,
            take_trade=fusion_result.take_trade,
            direction=fusion_result.direction,
            confidence=fusion_result.confidence,
            position_size_dollars=size_dollars,
            position_size_contracts=size_contracts,
            entry_price=entry_price,
            target_price=target_price,
            stop_price=stop_price,
            max_loss=max_loss,
            research_summary=research,
            fusion_result=asdict(fusion_result) if hasattr(fusion_result, '__dataclass_fields__') else {},
            reasoning=fusion_result.reasoning,
            timestamp=datetime.now().isoformat()
        )
        
        # Log decision
        if decision.take_trade:
            self.logger.info(f"✅ APPROVED: {candidate.ticker} {candidate.strike} {candidate.option_type} {fusion_result.direction}")
            self.logger.info(f"   Confidence: {fusion_result.confidence:.0f}%")
            self.logger.info(f"   Size: {size_contracts} contracts (${size_dollars:.0f})")
        else:
            self.logger.info(f"❌ REJECTED: {fusion_result.reasoning}")
        
        return decision
    
    def _calculate_position_size(
        self,
        candidate: OptionCandidate,
        fusion_result
    ) -> tuple:
        """
        Calculate position size based on confidence and risk limits.
        
        Returns: (size_dollars, size_contracts, entry_price)
        """
        
        # Start with max position
        base_size = self.buying_power * MAX_POSITION_PCT
        
        # Adjust for confidence
        if fusion_result.confidence >= 80:
            size_mult = 1.0
        elif fusion_result.confidence >= 65:
            size_mult = 0.7
        elif fusion_result.confidence >= MIN_CONFIDENCE:
            size_mult = 0.5
        else:
            size_mult = 0
        
        # Apply fusion position size multiplier
        size_mult *= fusion_result.position_size_multiplier
        
        # Calculate size in dollars
        size_dollars = base_size * size_mult
        
        # Apply max loss limit
        max_loss_size = MAX_LOSS_DOLLARS / STOP_LOSS_PCT
        size_dollars = min(size_dollars, max_loss_size)
        
        # Calculate entry price (bid-anchored for buying)
        if fusion_result.direction == "LONG":
            spread = candidate.ask - candidate.bid
            entry_price = candidate.bid + (spread * 0.4)  # 40% above bid
        else:
            entry_price = candidate.ask - ((candidate.ask - candidate.bid) * 0.3)
        
        # Calculate contracts
        price_per_contract = entry_price * 100
        size_contracts = max(1, int(size_dollars / price_per_contract))
        
        # Recalculate actual dollar size
        size_dollars = size_contracts * price_per_contract
        
        return (size_dollars, size_contracts, entry_price)
    
    # =========================================================================
    # STEP 4: EXECUTE TRADES
    # =========================================================================
    
    def _execute_trade(self, decision: TradeDecision):
        """
        Execute an approved trade.
        Paper mode: Log the trade
        Live mode: Place order via Robinhood
        """
        
        if self.paper_mode:
            self._paper_trade(decision)
        else:
            self._live_trade(decision)
    
    def _paper_trade(self, decision: TradeDecision):
        """Simulate a trade in paper mode."""
        
        trade = {
            "id": len(self.trade_history) + 1,
            "ticker": decision.candidate.ticker,
            "strike": decision.candidate.strike,
            "expiry": decision.candidate.expiry,
            "type": decision.candidate.option_type,
            "direction": decision.direction,
            "contracts": decision.position_size_contracts,
            "entry_price": decision.entry_price,
            "target_price": decision.target_price,
            "stop_price": decision.stop_price,
            "status": "OPEN",
            "entry_time": datetime.now().isoformat(),
            "exit_time": None,
            "exit_price": None,
            "pnl": None,
            "reasoning": decision.reasoning
        }
        
        self.positions.append(trade)
        self.trade_history.append(trade)
        
        self.logger.info(f"📝 PAPER TRADE: Opened {trade['direction']} {trade['contracts']}x {trade['ticker']} {trade['strike']} @ ${trade['entry_price']:.2f}")
    
    def _live_trade(self, decision: TradeDecision):
        """Execute a real trade via Robinhood."""
        # TODO: Implement Robinhood order placement
        self.logger.warning("Live trading not implemented yet")
    
    # =========================================================================
    # STEP 5: MONITOR POSITIONS
    # =========================================================================
    
    def _monitor_positions(self):
        """Check open positions for exit conditions."""
        
        if not self.positions:
            return
        
        self.logger.info(f"Monitoring {len(self.positions)} open position(s)...")
        
        for position in self.positions:
            if position["status"] != "OPEN":
                continue
            
            # Get current price (mock in paper mode)
            current_price = self._get_current_price(position)
            
            # Check exit conditions
            pnl_pct = (current_price - position["entry_price"]) / position["entry_price"]
            
            if position["direction"] == "LONG":
                if pnl_pct >= PROFIT_TARGET_PCT:
                    self._exit_position(position, current_price, "TARGET_HIT")
                elif pnl_pct <= -STOP_LOSS_PCT:
                    self._exit_position(position, current_price, "STOP_HIT")
            else:
                # SHORT - P&L is inverted
                if pnl_pct <= -PROFIT_TARGET_PCT:
                    self._exit_position(position, current_price, "TARGET_HIT")
                elif pnl_pct >= STOP_LOSS_PCT:
                    self._exit_position(position, current_price, "STOP_HIT")
    
    def _get_current_price(self, position: dict) -> float:
        """Get current price of a position."""
        if self.paper_mode:
            # Mock price movement
            import random
            return position["entry_price"] * (1 + random.uniform(-0.1, 0.2))
        
        # TODO: Get real price from Robinhood
        return position["entry_price"]
    
    def _exit_position(self, position: dict, exit_price: float, reason: str):
        """Exit a position."""
        
        position["status"] = "CLOSED"
        position["exit_time"] = datetime.now().isoformat()
        position["exit_price"] = exit_price
        
        # Calculate P&L
        if position["direction"] == "LONG":
            pnl = (exit_price - position["entry_price"]) * position["contracts"] * 100
        else:
            pnl = (position["entry_price"] - exit_price) * position["contracts"] * 100
        
        position["pnl"] = pnl
        self.daily_pnl += pnl
        
        emoji = "💰" if pnl > 0 else "💸"
        self.logger.info(f"{emoji} CLOSED: {position['ticker']} {position['strike']} | {reason} | P&L: ${pnl:+.2f}")
    
    # =========================================================================
    # UTILITIES
    # =========================================================================
    
    def _is_market_open(self) -> bool:
        """Check if market is currently open."""
        now = datetime.now()
        
        # Weekend check
        if now.weekday() >= 5:
            return False
        
        # Hours check (9:30 AM - 4:00 PM ET)
        market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
        market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
        
        return market_open <= now <= market_close
    
    def _log_status(self):
        """Log current status."""
        
        usage = self.research_agent.get_usage_stats()
        
        self.logger.info(f"\n📈 STATUS:")
        self.logger.info(f"   Scans: {self.scan_count}")
        self.logger.info(f"   Open positions: {len([p for p in self.positions if p.get('status') == 'OPEN'])}")
        self.logger.info(f"   Daily P&L: ${self.daily_pnl:+.2f}")
        self.logger.info(f"   API usage: {usage['searches_today']} searches, {usage['tokens_today']} tokens (${usage['estimated_cost']:.4f})")
    
    def _save_state(self):
        """Save current state to file."""
        
        state = {
            "positions": self.positions,
            "trade_history": self.trade_history,
            "daily_pnl": self.daily_pnl,
            "scan_count": self.scan_count,
            "timestamp": datetime.now().isoformat()
        }
        
        with open("/home/claude/lauren_v9/data/state.json", "w") as f:
            json.dump(state, f, indent=2)
        
        self.logger.info("State saved to data/state.json")


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="LAUREN V9 Trading Agent")
    parser.add_argument("--live", action="store_true", help="Run in live mode (default: paper)")
    parser.add_argument("--single", action="store_true", help="Run a single scan cycle then exit")
    parser.add_argument("--buying-power", type=float, default=10000, help="Buying power (default: 10000)")
    
    args = parser.parse_args()
    
    agent = TradingAgent(
        paper_mode=not args.live,
        buying_power=args.buying_power
    )
    
    if args.single:
        agent.scan_cycle()
    else:
        agent.run()
